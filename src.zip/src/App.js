import './App.css';
import VotingApp from './VotingApp';
function App() {
  return (
    <div>
    <VotingApp />
    </div>
  );
}

export default App;
