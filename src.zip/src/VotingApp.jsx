import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Styles.css"; // Import external CSS file

const VotingApp = () => {
  const [polls, setPolls] = useState([]);
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState("");

  useEffect(() => {
    fetchPolls();
  }, []);

  const fetchPolls = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/polls");
      setPolls(response.data);
    } catch (error) {
      console.error("Error fetching polls:", error);
    }
  };

  const createPoll = async () => {
    try {
      const newPoll = { question, options: options.split(",").map((opt) => opt.trim()) };
      await axios.post("http://localhost:5000/api/polls", newPoll);
      setQuestion("");
      setOptions("");
      fetchPolls();
    } catch (error) {
      console.error("Error creating poll:", error);
    }
  };

  const vote = async (pollId, option) => {
    try {
      await axios.post(`http://localhost:5000/api/vote/${pollId}`, { option });
      alert("✅ Vote submitted successfully!");
      fetchPolls();
    } catch (error) {
      console.error("Error voting:", error);
    }
  };

  return (
    <div className="container">
      <h1>🗳️ Voting App</h1>

      {/* Create Poll Section */}
      <input
        type="text"
        placeholder="Poll Question"
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
      />
      <input
        type="text"
        placeholder="Options (comma-separated)"
        value={options}
        onChange={(e) => setOptions(e.target.value)}
      />
      <button onClick={createPoll}>➕ Create Poll</button>

      {/* List Polls Section */}
      {polls.length === 0 ? <p>No polls available.</p> : (
        polls.map((poll) => (
          <div key={poll._id} className="poll">
            <h2>{poll.question}</h2>
            {poll.options.map((option, index) => (
              <button key={index} onClick={() => vote(poll._id, option)}>
                {option} ({poll.votes[option] || 0} votes)
              </button>
            ))}
          </div>
        ))
      )}
    </div>
  );
};

export default VotingApp;
